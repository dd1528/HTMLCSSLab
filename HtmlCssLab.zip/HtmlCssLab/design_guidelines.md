# Design Guidelines: Travel Website Homepage Lab

## Design Approach
**Reference-Based Approach**: Drawing inspiration from travel platforms like Airbnb and Booking.com, with emphasis on visual storytelling through imagery and clean, accessible layouts.

## Core Design Principles
- **Visual-First Experience**: Large, immersive photography drives engagement
- **Clear Hierarchy**: Navigation → Hero → Card Grid flow guides user attention
- **Accessible Tourism**: Clean typography and adequate spacing ensure readability
- **Social Proof Integration**: Display engagement metrics to build trust

---

## Typography

**Font Family**: Open Sans (Google Fonts)
- Primary font for entire application
- Weights: 300 (light/body), 400 (regular), 600 (semi-bold/nav), 800 (heavy/emphasis)

**Type Scale**:
- Hero Heading (h2): 48px, weight 600
- Hero Subheading (p): 24px, weight 300  
- Card Titles (h3): 20-24px, weight 600
- Card Descriptions: 14-16px, weight 300
- Navigation Links: 14px, weight 600, uppercase, letter-spacing 0.5px
- Social Metrics: 12-14px, weight 400

---

## Layout System

**Spacing Units**: Use Tailwind-style spacing with base-8 system
- Common units: 0.5rem (8px), 1rem (16px), 1.5rem (24px), 2rem (32px), 5rem (80px)
- Hero text margin: 100px top, 80px left
- Card padding: 1.5rem (24px) internal
- Navigation padding: 20px vertical, variable horizontal

**Grid Structure**:
- Cards: 3-column grid on desktop, 1-column on mobile
- Each card: Float left, width 33.33% (desktop), 100% (mobile)
- Card spacing: Consistent gaps between elements

**Container Constraints**:
- Navigation: Full-width (100%)
- Header: Full-width, min-height 500px
- Cards: Equal-width columns with slight margins between

---

## Component Library

### Navigation
- Fixed position at top of header
- Logo: 60px SVG, positioned top-left (10px, 5px offset)
- Horizontal list navigation aligned after logo (80px left margin)
- List items: inline-block, no bullets
- Links: Medium font weight, uppercase, adequate padding (10px)

### Hero Section
- Full-width background image (cover sizing)
- Text overlay: White color for contrast over dark imagery
- Vertical positioning: Roughly centered (100px from top)
- Horizontal alignment: Match navigation left margin (80px)
- Button: Rounded corners (5px), ample padding (10px 20px)

### Cards
- Floating grid layout with equal-width columns
- Card structure (top to bottom):
  1. Full-width image (landscape aspect ratio)
  2. Content container with padding
  3. Title (h3)
  4. Description text (lighter weight)
  5. Social metrics row with icons

### Social Metrics
- Heart icon with count (favorites)
- Comment icon with count (engagement)
- Icons: Use Font Awesome or similar icon library
- Display inline with spacing between metrics

### Buttons/CTAs
- Primary style: Solid background with white text
- Rounded corners (5px border-radius)
- Generous padding for touch targets
- Background blur when overlaying images for readability

---

## Visual Treatments

**Color References** (per lab specifications):
- Primary Purple: #51279b (navigation links, buttons)
- Lighter Purple: #8662c7 (visited links, hover states)
- Background: #F0F4F8 (light gray-blue)
- Text Overlay: White (for hero section)

**Interactive States**:
- Links: Underline on hover
- Buttons: Lighter shade on hover (#8662c7)
- No active state animations (per requirement)

---

## Images

**Hero Image**:
- Large landscape photograph of scenic destination
- Full-width background image with cover sizing
- Dark or mid-tone image for white text contrast
- Located in `/images` folder (specified in lab files)

**Logo**:
- SVG format, 60px sizing
- Positioned as background image in navigation
- Non-repeating, fixed position

**Card Images**:
- Three destination photographs:
  1. Nova Scotia (card1.jpg) - Maritime/sailing scene
  2. Santorini (card2.jpg) - Sunset/dusk imagery  
  3. Amsterdam (card3.jpg) - Flower market scene
- Landscape orientation, consistent aspect ratio
- Full-width within card containers

---

## Responsive Considerations

**Desktop (>768px)**:
- Three-column card grid
- Full navigation horizontal layout
- Hero text positioned left-aligned with generous margins

**Mobile (<768px)**:
- Single-column card stack
- Simplified navigation (potentially collapsible)
- Hero text scaled down appropriately
- Maintained readability and touch targets

---

## Accessibility

- Adequate color contrast for text overlays
- Touch-friendly button sizing (minimum 44px tap targets)
- Semantic HTML structure (nav, header, main, section)
- Alt text for all images
- Focus states for keyboard navigation